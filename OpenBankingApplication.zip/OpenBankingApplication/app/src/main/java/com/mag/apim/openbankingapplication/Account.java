package com.mag.apim.openbankingapplication;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.ca.mas.foundation.MAS;
import com.ca.mas.foundation.MASCallback;
import com.ca.mas.foundation.MASConstants;
import com.ca.mas.foundation.MASRequest;
import com.ca.mas.foundation.MASResponse;

import org.json.JSONObject;
import org.w3c.dom.Text;

import java.net.HttpURLConnection;
import java.net.URISyntaxException;

public class Account extends AppCompatActivity {


    TextView mdisplayResponse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        mdisplayResponse = (TextView) findViewById(R.id.tv_dataDisplay) ;

        Button mRates = (Button) findViewById(R.id.bt_Rates);
        mRates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               getInterest();
                /*try {
                    invokeAPI("/team4/getInterest");
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }*/
            }
        });

        Button mProfile = (Button) findViewById(R.id.bt_profile);
        mProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //invokeAPI("/team4/accountProfile");
                    invokeAPI("/openid/connect/v1/userinfo");
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
            }
        });

        Button mBalance = (Button) findViewById(R.id.bt_balance);
        mBalance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    invokeAPI("/team4/accountBalance");
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
            }
        });

        Button mTransfer = (Button) findViewById(R.id.bt_transfer);
        mTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                doTransfer();
               /* try {
                    invokeAPI("/team4/balanceTransfer");
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }*/
            }
        });





        MAS.start(this, true);

    }


    public void doTransfer(){
        Intent intent = new Intent(this, BalanceTransfer.class);
        startActivity(intent);
    }

    public void getInterest(){
        Intent intent = new Intent(this, InterestActivity.class);
        startActivity(intent);
    }

    private void invokeAPI(String path) throws URISyntaxException {

        //String endPoint = "/team4/getInterest";
        Uri.Builder uriBuilder = new Uri.Builder().encodedPath(path);
        Uri uri = uriBuilder.appendQueryParameter("amount", "500").build();
        MASRequest requestBuilder = new MASRequest.MASRequestBuilder(uri)
                .get().build();

        MAS.invoke(requestBuilder, new MASCallback<MASResponse<JSONObject>>() {

            @Override
            public void onSuccess(MASResponse<JSONObject> response) {
                //Check for the response code;
                //The module considers success when receiving a response with HTTP status code range 200-299
                if (HttpURLConnection.HTTP_OK == response.getResponseCode()) {

                    updateResults(response.getBody().getContent().toString());
                    //JSONObject j = response.getBody().getContent();
                    //mDisplayResults.setText(response.getBody().getContent().toString());
                }
            }

            @Override
            public void onError(Throwable e) {
                updateResults(e.getMessage());
            }
        });


    }

    private void updateResults(String values){
        final String val = values;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                mdisplayResponse.setText(val);
            }
        });
    }
}
