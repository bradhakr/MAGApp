package com.mag.apim.openbankingapplication;


import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.ca.mas.foundation.MAS;
import com.ca.mas.foundation.MASCallback;
import com.ca.mas.foundation.MASRequest;
import com.ca.mas.foundation.MASResponse;

import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URISyntaxException;

public class BalanceTransfer extends AppCompatActivity {

    private TextView tv_transferResults;
    private TextView tv_amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_balance_transfer);

        tv_transferResults = (TextView) findViewById(R.id.tv_transferResults) ;
        tv_amount = (TextView) findViewById(R.id.tv_amounts) ;

        Spinner spinnerFrom = (Spinner) findViewById(R.id.fromAccount);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterFrom = ArrayAdapter.createFromResource(this,
                R.array.accounts, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapterFrom.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinnerFrom.setAdapter(adapterFrom);

        Spinner spinnerB = (Spinner) findViewById(R.id.toAccount);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterTo = ArrayAdapter.createFromResource(this,
                R.array.accounts, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapterTo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinnerB.setAdapter(adapterTo);

        Button mUSerTransfer = (Button) findViewById(R.id.bt_UserbalanceTranser);
        mUSerTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    invokeAPI("/team4/balanceTransfer");
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
            }
        });

        MAS.start(this, true);

    }

    private void invokeAPI(String path) throws URISyntaxException {

        //String endPoint = "/team4/getInterest";
        Uri.Builder uriBuilder = new Uri.Builder().encodedPath(path);
        Uri uri = uriBuilder.appendQueryParameter("amount", tv_amount.getText().toString()).build();
        MASRequest requestBuilder = new MASRequest.MASRequestBuilder(uri)
                .get().build();

        MAS.invoke(requestBuilder, new MASCallback<MASResponse<JSONObject>>() {

            @Override
            public void onSuccess(MASResponse<JSONObject> response) {
                //Check for the response code;
                //The module considers success when receiving a response with HTTP status code range 200-299
                if (HttpURLConnection.HTTP_OK == response.getResponseCode()) {

                    updateResults(response.getBody().getContent().toString());
                    //JSONObject j = response.getBody().getContent();
                    //mDisplayResults.setText(response.getBody().getContent().toString());
                }
            }

            @Override
            public void onError(Throwable e) {
                updateResults(e.getMessage());
            }
        });


    }

    private void updateResults(String values){
        final String val = values;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                tv_transferResults.setText(val);
            }
        });
    }
}
