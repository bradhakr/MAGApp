package com.mag.apim.openbankingapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ca.mas.foundation.MAS;
import com.ca.mas.foundation.MASCallback;
import com.ca.mas.foundation.MASUser;

public class LoginActivity extends AppCompatActivity {


    private EditText musername;
    private EditText mpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        musername = (EditText) findViewById(R.id.et_username);
        musername.setText("");

        mpassword = (EditText) findViewById(R.id.et_password);
        mpassword.setText("");

        Button mSignIn = (Button) findViewById(R.id.bt_login);
        mSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Login();
            }
        });

        Button mlogoff = (Button) findViewById(R.id.bt_logoff);
        mlogoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doServerLogout();
            }
        });

        Button mClearButton = (Button) findViewById(R.id.bt_clear);
        mClearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearTextViews();
            }
        });


        MAS.start(this, true);

    }

    private void Login() {
        // - The password typed in the password field
        String mPassword = mpassword.getText().toString();

        // - The user typed in the PMFKey field
        String mUser = musername.getText().toString();

        MASUser.login(mUser, mPassword.toCharArray(), new MASCallback<MASUser>() {
            @Override
            public void onSuccess(MASUser result) {
                showMessage("Successful Logged in", Toast.LENGTH_SHORT);
                getAccount();
            }

            @Override
            public void onError(Throwable e) {
                showMessage("Login Failed, Please Contact Admin", Toast.LENGTH_SHORT);
            }
        });
    }


    private void clearTextViews() {
        musername.setText("");
        mpassword.setText("");
    }

    public void getAccount(){
        Intent intent = new Intent(this, Account.class);
        startActivity(intent);
    }

    public void showMessage(final String message, final int toastLength) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(LoginActivity.this, message, toastLength).show();
            }
        });
    }

    private void doServerLogout() {

        if (MASUser.getCurrentUser() != null) {
            MASUser.getCurrentUser().logout(true, new MASCallback<Void>() {
                @Override
                public void onSuccess(Void result) {
                    //updateResults("Welcome to Open Banking Application");
                    showMessage("Successful Logout", Toast.LENGTH_SHORT);
                    goMain();
                }

                @Override
                public void onError(Throwable e) {
                    showMessage("Fail Logout", Toast.LENGTH_SHORT);
                }
            });
        }
    }

    public void goMain(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }







}
