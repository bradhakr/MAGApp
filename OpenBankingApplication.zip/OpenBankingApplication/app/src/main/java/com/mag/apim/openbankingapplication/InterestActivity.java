package com.mag.apim.openbankingapplication;

import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.ca.mas.foundation.MAS;
import com.ca.mas.foundation.MASCallback;
import com.ca.mas.foundation.MASConstants;
import com.ca.mas.foundation.MASRequest;
import com.ca.mas.foundation.MASResponse;

import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URISyntaxException;

import static android.text.Html.FROM_HTML_MODE_COMPACT;

public class InterestActivity extends AppCompatActivity {

    //private TextView mTextMessage;
    private WebView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    //mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    //mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interest);

        mTextMessage = (WebView) findViewById(R.id.tv_ratesWebView);

        Button mBTrates = (Button) findViewById(R.id.bt_ratesFetch);
        mBTrates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getInterest();
            }
        });

        Button mBTclear = (Button) findViewById(R.id.bt_rateClear);
        mBTclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearFields();
            }
        });

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        MAS.start(this, true);

    }

    public void getInterest(){

        try{
            invokeAPI();
        }catch(Exception e){
            showMessage(e.getMessage(), Toast.LENGTH_LONG);
        }
    }

    public void showMessage(final String message, final int toastLength) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText( InterestActivity.this, message, toastLength).show();
            }
        });
    }

    private void invokeAPI() throws URISyntaxException {

        String endPoint = "/team4/getInterest";
        Uri.Builder uriBuilder = new Uri.Builder().encodedPath(endPoint);
        Uri uri = uriBuilder.appendQueryParameter("operation", "listProducts").build();
        MASRequest requestBuilder = new MASRequest.MASRequestBuilder(uri)
                .get().build();

        MAS.setGrantFlow(MASConstants.MAS_GRANT_FLOW_CLIENT_CREDENTIALS);
        MAS.invoke(requestBuilder, new MASCallback<MASResponse<String>>() {

            @Override
            public void onSuccess(MASResponse<String> response) {
                //Check for the response code;
                //The module considers success when receiving a response with HTTP status code range 200-299
                if (HttpURLConnection.HTTP_OK == response.getResponseCode()) {

                    updateResults(response.getBody().getContent().toString());
                    MAS.setGrantFlow(MASConstants.MAS_GRANT_FLOW_PASSWORD);
                    //JSONObject j = response.getBody().getContent();
                    //mDisplayResults.setText(response.getBody().getContent().toString());
                }
            }

            @Override
            public void onError(Throwable e) {
                MAS.setGrantFlow(MASConstants.MAS_GRANT_FLOW_PASSWORD);
                updateResults(e.getMessage());
            }
        });


    }

    private void updateResults(String values){
        final String val = values;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mTextMessage.loadData(val, "text/html;charset=UTF-8", "null");
            }
        });
    }

    public void clearFields(){
        mTextMessage.loadData("", "text/html", "base64");
    }

}
