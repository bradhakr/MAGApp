package com.mag.apim.openbankingapplication;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.ca.mas.foundation.MAS;
import com.ca.mas.foundation.MASCallback;
import com.ca.mas.foundation.MASConfiguration;
import com.ca.mas.foundation.MASConstants;
import com.ca.mas.foundation.MASRequest;
import com.ca.mas.foundation.MASResponse;
import com.ca.mas.foundation.MASSecurityConfiguration;
import com.ca.mas.foundation.MASSessionUnlockCallback;
import com.ca.mas.foundation.MASUser;

import org.json.JSONObject;
import org.w3c.dom.Text;

import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TextView mdisplay;
    URL mUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mdisplay = (TextView) findViewById(R.id.tv_dispaly);

        MAS.debug();
        MAS.start(this, true);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.banking, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.mi_account:
                getAccount();
                return true;
            case R.id.mi_balance:
                getAccount();
                return true;
            case R.id.mi_profile:
                getAccount();
                return true;
            case R.id.mi_rates:
                getRates();
                return true;
            case R.id.mi_transfer:
                doTransfer();
                return true;
            case R.id.mi_login:
                login();
                return true;
            case R.id.mi_logoff:
                doServerLogout();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void getProfile(){
        Intent intent = new Intent(this, Account.class);
        startActivity(intent);
        showMessage("Successfully Profile has been Retrieved!!!", Toast.LENGTH_SHORT);
    }

    public void getAccount(){
        Intent intent = new Intent(this, Account.class);
        startActivity(intent);
        showMessage("Successfully Account has been Retrieved!!!", Toast.LENGTH_SHORT);
    }

    public void getRates(){
        Intent intent = new Intent(this, InterestActivity.class);
        startActivity(intent);
        showMessage("Successfully Rates has been Retrieved!!!", Toast.LENGTH_SHORT);
    }

    public void getBalance(){
        showMessage("Successfully Balance has been Retrieved!!!", Toast.LENGTH_SHORT);
    }

    public void doTransfer(){
        Intent intent = new Intent(this, BalanceTransfer.class);
        startActivity(intent);
        showMessage("Successfully Transfer has been Completed!!!", Toast.LENGTH_SHORT);
    }

    public void login(){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        //showMessage("Login successfull!!!", Toast.LENGTH_SHORT);
    }


    private void doServerLogout() {

        if (MASUser.getCurrentUser() != null) {
            MASUser.getCurrentUser().logout(true, new MASCallback<Void>() {
                @Override
                public void onSuccess(Void result) {
                    updateResults("Welcome to Open Banking Application");
                    showMessage("Successful Logout", Toast.LENGTH_SHORT);
                }

                @Override
                public void onError(Throwable e) {
                    showMessage("Fail Logout", Toast.LENGTH_SHORT);
                }
            });
        }
    }

    public void showMessage(final String message, final int toastLength) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText( MainActivity.this, message, toastLength).show();
            }
        });
    }

    public void loadIntent(Activity activity){
        Intent intent = new Intent(this, activity.getClass());
        startActivity(intent);
    }

    private void invokeAPI() throws URISyntaxException {

        String endPoint = "/team4/getInterest";
        Uri.Builder uriBuilder = new Uri.Builder().encodedPath(endPoint);
        Uri uri = uriBuilder.appendQueryParameter("operation", "listProducts").build();
        MASRequest requestBuilder = new MASRequest.MASRequestBuilder(uri)
                .get().build();

        MAS.setGrantFlow(MASConstants.MAS_GRANT_FLOW_CLIENT_CREDENTIALS);
        MAS.invoke(requestBuilder, new MASCallback<MASResponse<JSONObject>>() {

            @Override
            public void onSuccess(MASResponse<JSONObject> response) {
                //Check for the response code;
                //The module considers success when receiving a response with HTTP status code range 200-299
                if (HttpURLConnection.HTTP_OK == response.getResponseCode()) {

                    updateResults(response.getBody().getContent().toString());
                    MAS.setGrantFlow(MASConstants.MAS_GRANT_FLOW_PASSWORD);
                    //JSONObject j = response.getBody().getContent();
                    //mDisplayResults.setText(response.getBody().getContent().toString());
                }
            }

            @Override
            public void onError(Throwable e) {
                MAS.setGrantFlow(MASConstants.MAS_GRANT_FLOW_PASSWORD);
                updateResults(e.getMessage());
            }
        });


    }

    private void updateResults(String values){
        final String val = values;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mdisplay.setText(val);
            }
        });
    }


    // - TODO: Complete this method Exercise 6
    /**
     * Implement the lock session feature
     * @see <a href="http://mas.ca.com/docs/android/1.8.00/guides/#device-lockunlock-session">Implement Lock Session</a>
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void LockSession(){

        MASUser currentUser = MASUser.getCurrentUser();
        if (currentUser != null) {
            currentUser.lockSession(null);
        }

    }

    // - TODO: Complete this method Exercise 6
    /**
     * Implement the unlock session feature
     * @see <a href="http://mas.ca.com/docs/android/1.8.00/guides/#device-lockunlock-session">Implement Lock Session</a>
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void UnlockSession(){

        MASUser currentUser = MASUser.getCurrentUser();
        if (currentUser != null) {
            currentUser.unlockSession(getUnlockCallback());
        }
    }

    public MASSessionUnlockCallback<Void> getUnlockCallback() {
        return new MASSessionUnlockCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                // The session was successfully unlocked
            }

            @Override
            public void onError(Throwable e) {
                // Handle errors
            }

            @Override
            @TargetApi(23)
            public void onUserAuthenticationRequired() {
                // Handle user authentication
                launchKeyguardIntent();
            }
        };
    }

        protected int REQUEST_CODE = 0x1000;

        // Launch the default Android lockscreen to authenticate the user
        private void launchKeyguardIntent() {
            KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            Intent intent = keyguardManager.createConfirmDeviceCredentialIntent("Confirm your pattern",
                    "Please provide your credentials.");
            if (intent != null) {
                startActivityForResult(intent, REQUEST_CODE);
            }
        }




    @Override
    protected void onPause() {

        //this.LockSession();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        UnlockSession();
    }

}
